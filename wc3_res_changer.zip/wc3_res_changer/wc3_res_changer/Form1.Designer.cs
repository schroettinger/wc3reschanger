﻿namespace wc3_res_changer
{
    partial class frm_main
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_change = new System.Windows.Forms.Button();
            this.txtBx_width = new System.Windows.Forms.TextBox();
            this.txtBx_height = new System.Windows.Forms.TextBox();
            this.label_width = new System.Windows.Forms.Label();
            this.label_heigth = new System.Windows.Forms.Label();
            this.btn_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_change
            // 
            this.btn_change.Location = new System.Drawing.Point(166, 13);
            this.btn_change.Name = "btn_change";
            this.btn_change.Size = new System.Drawing.Size(75, 20);
            this.btn_change.TabIndex = 0;
            this.btn_change.Text = "change";
            this.btn_change.UseVisualStyleBackColor = true;
            this.btn_change.Click += new System.EventHandler(this.btn_change_Click);
            // 
            // txtBx_width
            // 
            this.txtBx_width.Location = new System.Drawing.Point(50, 13);
            this.txtBx_width.Name = "txtBx_width";
            this.txtBx_width.Size = new System.Drawing.Size(100, 20);
            this.txtBx_width.TabIndex = 1;
            this.txtBx_width.WordWrap = false;
            // 
            // txtBx_height
            // 
            this.txtBx_height.Location = new System.Drawing.Point(50, 51);
            this.txtBx_height.Name = "txtBx_height";
            this.txtBx_height.Size = new System.Drawing.Size(100, 20);
            this.txtBx_height.TabIndex = 1;
            this.txtBx_height.WordWrap = false;
            // 
            // label_width
            // 
            this.label_width.AutoSize = true;
            this.label_width.Location = new System.Drawing.Point(8, 13);
            this.label_width.Name = "label_width";
            this.label_width.Size = new System.Drawing.Size(35, 13);
            this.label_width.TabIndex = 2;
            this.label_width.Text = "width:";
            // 
            // label_heigth
            // 
            this.label_heigth.AutoSize = true;
            this.label_heigth.Location = new System.Drawing.Point(8, 51);
            this.label_heigth.Name = "label_heigth";
            this.label_heigth.Size = new System.Drawing.Size(36, 13);
            this.label_heigth.TabIndex = 2;
            this.label_heigth.Text = "heigth";
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(166, 51);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(75, 20);
            this.btn_close.TabIndex = 3;
            this.btn_close.Text = "close";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "´written by Daniel Schroeder 2014";
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 110);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.label_heigth);
            this.Controls.Add(this.label_width);
            this.Controls.Add(this.txtBx_height);
            this.Controls.Add(this.txtBx_width);
            this.Controls.Add(this.btn_change);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_main";
            this.Text = "wc3 resolution changer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_change;
        private System.Windows.Forms.TextBox txtBx_width;
        private System.Windows.Forms.TextBox txtBx_height;
        private System.Windows.Forms.Label label_width;
        private System.Windows.Forms.Label label_heigth;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label label1;
    }
}

