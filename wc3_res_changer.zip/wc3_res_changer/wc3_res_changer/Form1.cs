﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace wc3_res_changer
{
    

    public partial class frm_main : Form
    {

       RegistryKey sk1 = Registry.CurrentUser.OpenSubKey("Software\\Blizzard Entertainment\\Warcraft III\\Video", true);

        public frm_main()
        {
            InitializeComponent();
            
            // If the RegistrySubKey doesn't exist -> (null)
            try
            {
                if (sk1 == null)
                {
                    MessageBox.Show("Either there are no WC3 keys available at\n\"\\HKEY_CURRENT_USER\\Software\\Blizzard Entertainment\\Warcraft III\\Video\"!\nor you have no access to them.");
                }       
             
                txtBx_width.Text = sk1.GetValue("reswidth").ToString();
                txtBx_height.Text = sk1.GetValue("resheight").ToString();
            }
            catch(Exception e)
            {
                this.Close();
            }

        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_change_Click(object sender, EventArgs e)
        {
            sk1.SetValue("reswidth", Convert.ToDecimal(txtBx_width.Text), RegistryValueKind.DWord);
            sk1.SetValue("resheight", Convert.ToDecimal(txtBx_height.Text), RegistryValueKind.DWord);

            MessageBox.Show("New width:\t" + sk1.GetValue("reswidth").ToString() + "\n" + "New height:\t" + sk1.GetValue("resheight").ToString());
        }
    }
}
